<nav class="navbar">
    <div class="nav-brand">
        <a href="dashboard.php" class="brand-link">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Staff Portal</span>
        </a>
    </div>
    
    <div class="nav-links">
        <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</nav>

<style>
    .navbar {
        background: white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        padding: 0.75rem 1.5rem;
        position: sticky;
        top: 0;
        z-index: 1000;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .nav-brand {
        display: flex;
        align-items: center;
    }

    .brand-link {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-size: 1.25rem;
        font-weight: 600;
        color: #2c3e50;
        text-decoration: none;
        transition: color 0.3s;
    }

    .brand-link:hover {
        color: #3498db;
    }

    .nav-links {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem 1rem;
        color: #64748b;
        text-decoration: none;
        border-radius: 6px;
        transition: all 0.3s;
    }

    .nav-link:hover {
        background: #f1f5f9;
        color: #3498db;
    }

    .nav-link.active {
        background: #e9f2fe;
        color: #3498db;
        font-weight: 500;
    }

    .nav-link i {
        font-size: 1.1rem;
        width: 1.5rem;
        text-align: center;
    }

    .nav-link:last-child {
        margin-left: 1rem;
        background: #fee2e2;
        color: #dc2626;
    }

    .nav-link:last-child:hover {
        background: #fecaca;
        color: #b91c1c;
    }

    @media (max-width: 768px) {
        .navbar {
            padding: 0.5rem 1rem;
        }

        .nav-link span {
            display: none;
        }

        .nav-link {
            padding: 0.75rem;
        }

        .nav-link i {
            font-size: 1.25rem;
            margin: 0;
        }
    }
</style>
