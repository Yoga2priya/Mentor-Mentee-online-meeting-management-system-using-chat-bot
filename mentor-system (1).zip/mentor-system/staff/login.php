<?php
session_start();
require_once '../config/db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $conn = $database->getConnection();
    if (!$conn) {
        die("Database connection failed");
    }
    
    try {
        $employee_id = $_POST['employee_id'];
        $password = $_POST['password'];
        
        if (empty($employee_id) || empty($password)) {
            throw new Exception("All fields are required");
        }
        
        // First check if the employee exists
        $stmt = $conn->prepare("SELECT * FROM staff WHERE employee_id = ?");
        $stmt->execute([$employee_id]);
        $staff = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($staff && password_verify($password, $staff['password'])) {
            // Clear any existing session data
            session_unset();
            session_regenerate_id(true);
            
            // Set staff session variables
            $_SESSION['user_type'] = 'staff';
            $_SESSION['staff_id'] = $staff['id'];
            $_SESSION['staff_name'] = $staff['name'];
            $_SESSION['staff_department'] = $staff['department'];
            
            header('Location: dashboard.php');
            exit();
        } else {
            throw new Exception("Invalid employee ID or password");
        }
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login - Student Information System</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <a href="../index.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
            
            <div class="login-header">
                <i class="fas fa-chalkboard-teacher login-icon"></i>
                <h2>Staff Login</h2>
                <p class="login-subtitle">Access your staff dashboard</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="employee_id">
                        <i class="fas fa-id-card"></i> Employee ID
                    </label>
                    <input type="text" name="employee_id" id="employee_id" required>
                </div>

                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="password-input">
                        <input type="password" name="password" id="password" required>
                        <i class="fas fa-eye toggle-password"></i>
                    </div>
                </div>

                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <div class="login-footer">
                <p>Don't have an account? <a href="register.php">Register here</a></p>
                <p class="help-text">Contact admin if you forgot your Employee ID</p>
            </div>
        </div>
    </div>

    <script>
        document.querySelector('.toggle-password').addEventListener('click', function() {
            const password = document.querySelector('#password');
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>
