<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

$staff_id = $_SESSION['staff_id'];

// Fetch staff details
$stmt = $conn->prepare("
    SELECT s.*, sr.role 
    FROM staff s
    LEFT JOIN staff_roles sr ON s.id = sr.staff_id
    WHERE s.id = ?
");
$stmt->execute([$staff_id]);
$staff = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $stmt = $conn->prepare("
            UPDATE staff 
            SET name = ?, email = ?, mobile_no = ?
            WHERE id = ?
        ");
        
        $stmt->execute([
            $_POST['name'],
            $_POST['email'],
            $_POST['mobile_no'],
            $staff_id
        ]);
        
        $success = "Profile updated successfully!";
        
        // Refresh staff data
        header('Location: profile.php?updated=true');
        exit();
    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Profile</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <h2>Staff Profile</h2>

        <?php if (isset($_GET['updated'])): ?>
            <div class="alert alert-success">Profile updated successfully!</div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="profile-container">
            <div class="profile-info">
                <form method="POST" class="profile-form">
                    <div class="form-group">
                        <label>Employee ID</label>
                        <input type="text" value="<?php echo htmlspecialchars($staff['employee_id']); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($staff['name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($staff['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Department</label>
                        <input type="text" value="<?php echo htmlspecialchars($staff['department']); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Designation</label>
                        <input type="text" value="<?php echo htmlspecialchars($staff['designation']); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Role</label>
                        <input type="text" value="<?php echo $staff['role'] ? ucfirst($staff['role']) : 'Staff'; ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Mobile Number</label>
                        <input type="text" name="mobile_no" value="<?php echo htmlspecialchars($staff['mobile_no']); ?>">
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-update">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>