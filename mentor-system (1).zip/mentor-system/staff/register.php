<?php
require_once '../config/db.php';
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $conn = $database->getConnection();
    
    try {
        // Hash password
        $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        // Insert staff
        $stmt = $conn->prepare("INSERT INTO staff (
            name, email, password, department, mobile_no, 
            designation, employee_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $_POST['name'],
            $_POST['email'],
            $hashed_password,
            $_POST['department'],
            $_POST['mobile_no'],
            $_POST['designation'],
            $_POST['employee_id']
        ]);
        
        header('Location: login.php?registered=true');
        exit();
    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration - Student Information System</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="registration-container">
        <div class="registration-box">
            <a href="../index.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
            
            <div class="registration-header">
                <i class="fas fa-chalkboard-teacher registration-icon"></i>
                <h2>Staff Registration</h2>
                <p class="registration-subtitle">Create your staff account</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="registration-form">
                <div class="form-sections">
                    <!-- Personal Information -->
                    <div class="form-section">
                        <h3><i class="fas fa-user"></i> Personal Information</h3>
                        
                        <div class="form-group">
                            <label for="name">
                                <i class="fas fa-user"></i> Full Name
                            </label>
                            <input type="text" id="name" name="name" required>
                        </div>

                        <div class="form-group">
                            <label for="employee_id">
                                <i class="fas fa-id-card"></i> Employee ID
                            </label>
                            <input type="text" id="employee_id" name="employee_id" required>
                        </div>

                        <div class="form-group">
                            <label for="department">
                                <i class="fas fa-building"></i> Department
                            </label>
                            <select id="department" name="department" required>
                                <option value="">Select Department</option>
                                <option value="BSc Computer Science">BSc Computer Science</option>
                                <option value="BSc Mathematics">BSc Mathematics</option>
                                <option value="BSc Physics">BSc Physics</option>
                                <option value="BSc Chemistry">BSc Chemistry</option>
                                <option value="BA English">BA English</option>
                                <option value="BA Tamil">BA Tamil</option>
                                <option value="BCom">BCom</option>
                                <option value="BBA">BBA</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="designation">
                                <i class="fas fa-user-tie"></i> Designation
                            </label>
                            <input type="text" id="designation" name="designation" required>
                        </div>
                    </div>

                    <!-- Contact Information -->
                    <div class="form-section">
                        <h3><i class="fas fa-address-card"></i> Contact Information</h3>
                        
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i> Email Address
                            </label>
                            <input type="email" id="email" name="email" required>
                        </div>

                        <div class="form-group">
                            <label for="mobile_no">
                                <i class="fas fa-phone"></i> Mobile Number
                            </label>
                            <input type="tel" id="mobile_no" name="mobile_no" required>
                        </div>

                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i> Password
                            </label>
                            <div class="password-input">
                                <input type="password" id="password" name="password" required>
                                <i class="fas fa-eye toggle-password"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="submit-btn">
                    <i class="fas fa-user-plus"></i> Register
                </button>
            </form>

            <div class="registration-footer">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </div>

    <script>
        document.querySelector('.toggle-password').addEventListener('click', function() {
            const password = document.querySelector('#password');
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>