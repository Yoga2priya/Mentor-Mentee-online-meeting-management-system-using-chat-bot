<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission for adding new placement record
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $conn->prepare("
            INSERT INTO placement_records 
            (student_id, company_name, position, package, offer_date, status, added_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $_POST['student_id'],
            $_POST['company_name'],
            $_POST['position'],
            $_POST['package'],
            $_POST['offer_date'],
            $_POST['status'],
            $_SESSION['staff_id']
        ]);
        
        $success = "Placement record added successfully!";
    } catch(Exception $e) {
        $error = "Error adding placement record: " . $e->getMessage();
    }
}

// Fetch all placement records with student names
$stmt = $conn->prepare("
    SELECT p.*, s.name as student_name, s.reg_no, st.name as staff_name
    FROM placement_records p
    JOIN students s ON p.student_id = s.id
    LEFT JOIN staff st ON p.added_by = st.id
    ORDER BY p.offer_date DESC
");
$stmt->execute();
$placements = $stmt->fetchAll();

// Fetch all students for the dropdown
$stmt = $conn->prepare("SELECT id, name, reg_no FROM students ORDER BY name");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Records</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        <h2>Placement Records Management</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="add-placement-section">
            <h3>Add New Placement Record</h3>
            <form method="POST" class="placement-form">
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo $student['name'] . ' (' . $student['reg_no'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="company_name">Company Name</label>
                    <input type="text" name="company_name" required>
                </div>

                <div class="form-group">
                    <label for="position">Position</label>
                    <input type="text" name="position" required>
                </div>

                <div class="form-group">
                    <label for="package">Package (LPA)</label>
                    <input type="number" step="0.01" name="package" required>
                </div>

                <div class="form-group">
                    <label for="offer_date">Offer Date</label>
                    <input type="date" name="offer_date" required>
                </div>

                <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" required>
                        <option value="placed">Placed</option>
                        <option value="in_process">In Process</option>
                        <option value="not_placed">Not Placed</option>
                    </select>
                </div>

                <button type="submit" class="btn-submit">Add Record</button>
            </form>
        </div>

        <div class="placement-records">
            <h3>All Placement Records</h3>
            <table class="records-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Register No</th>
                        <th>Company</th>
                        <th>Position</th>
                        <th>Package (LPA)</th>
                        <th>Offer Date</th>
                        <th>Status</th>
                        <th>Added By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($placements as $placement): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($placement['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($placement['reg_no']); ?></td>
                            <td><?php echo htmlspecialchars($placement['company_name']); ?></td>
                            <td><?php echo htmlspecialchars($placement['position']); ?></td>
                            <td><?php echo number_format($placement['package'], 2); ?></td>
                            <td><?php echo date('d M Y', strtotime($placement['offer_date'])); ?></td>
                            <td>
                                <span class="status-<?php echo $placement['status']; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $placement['status'])); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($placement['staff_name']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>