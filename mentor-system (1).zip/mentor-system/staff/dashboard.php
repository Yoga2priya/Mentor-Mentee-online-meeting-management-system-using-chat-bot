<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStaffLogin();

$database = new Database();
$conn = $database->getConnection();

// Fetch all students
$stmt = $conn->prepare("
    SELECT 
        s.id, s.name, s.reg_no, s.department, s.year, 
        s.photo_path, s.mobile_no, s.email
    FROM students s
    ORDER BY s.name
");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dashboard-container {
            max-width: 1400px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .welcome-section {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .welcome-section h2 {
            margin: 0;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card i {
            font-size: 2em;
            margin-bottom: 10px;
            color: #2a5298;
        }

        .stat-card h3 {
            margin: 0;
            color: #2c3e50;
            font-size: 1.1em;
        }

        .stat-card p {
            margin: 5px 0 0;
            font-size: 1.8em;
            font-weight: bold;
            color: #2a5298;
        }

        .search-section {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .search-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1.1em;
            transition: border-color 0.2s;
        }

        .search-input:focus {
            border-color: #2a5298;
            outline: none;
        }

        .students-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
            gap: 15px;
            padding: 20px 0;
        }

        .student-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            padding: 15px;
            gap: 20px;
            border: 1px solid #eef2f7;
        }

        .student-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
            border-color: #e2e8f0;
        }

        .student-photo-wrapper {
            width: 70px;
            height: 70px;
            border-radius: 12px;
            overflow: hidden;
            flex-shrink: 0;
            border: 3px solid #eef2f7;
        }

        .student-photo-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .no-photo {
            width: 100%;
            height: 100%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .no-photo i {
            font-size: 1.5em;
            color: #adb5bd;
        }

        .student-info-section {
            flex: 1;
            min-width: 0;
            padding-right: 15px;
        }

        .student-name {
            color: #2d3748;
            font-size: 1.15em;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .student-details-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9em;
            color: #4a5568;
        }

        .detail-item i {
            color: #4299e1;
            width: 16px;
        }

        .student-actions {
            display: flex;
            gap: 10px;
            align-items: center;
            border-left: 1px solid #eef2f7;
            padding-left: 20px;
        }

        .view-details-btn {
            background: #4299e1;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 0.9em;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .view-details-btn:hover {
            background: #3182ce;
            transform: translateY(-1px);
        }

        .view-details-btn i {
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>

    <div class="dashboard-container">
        <div class="welcome-section">
            <h2>Welcome, <?php echo $_SESSION['staff_name']; ?></h2>
            <p>Department of <?php echo $_SESSION['staff_department']; ?></p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-users"></i>
                <h3>Total Students</h3>
                <p><?php echo count($students); ?></p>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-graduate"></i>
                <h3>Department Students</h3>
                <p><?php echo count(array_filter($students, function($s) { 
                    return $s['department'] === $_SESSION['staff_department']; 
                })); ?></p>
            </div>
            <div class="stat-card">
                <i class="fas fa-calendar-check"></i>
                <h3>Today's Date</h3>
                <p><?php echo date('d M Y'); ?></p>
            </div>
        </div>

        <div class="search-section">
            <input type="text" id="studentSearch" placeholder="Search students by name or register number..." class="search-input">
        </div>

        <div class="students-grid">
            <?php foreach ($students as $student): ?>
                <div class="student-card">
                    <div class="student-photo-wrapper">
                        <?php if (!empty($student['photo_path'])): ?>
                            <img src="<?php echo '../' . $student['photo_path']; ?>" alt="Student Photo">
                        <?php else: ?>
                            <div class="no-photo">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="student-info-section">
                        <h3 class="student-name"><?php echo htmlspecialchars($student['name']); ?></h3>
                        <div class="student-details-grid">
                            <div class="detail-item">
                                <i class="fas fa-id-card"></i>
                                <span><?php echo htmlspecialchars($student['reg_no']); ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-building"></i>
                                <span><?php echo htmlspecialchars($student['department']); ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-graduation-cap"></i>
                                <span>Year <?php echo htmlspecialchars($student['year']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="student-actions">
                        <button class="view-details-btn" onclick="window.location.href='view_student.php?id=<?php echo $student['id']; ?>'">
                            <i class="fas fa-eye"></i>
                            View Details
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        document.getElementById('studentSearch').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const cards = document.querySelectorAll('.student-card');
            
            cards.forEach(card => {
                const name = card.dataset.name;
                const regno = card.dataset.regno;
                
                if (name.includes(searchTerm) || regno.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
