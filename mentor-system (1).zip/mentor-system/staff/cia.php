<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $conn->prepare("
            INSERT INTO cia_marks 
            (student_id, subject_code, subject_name, semester, cia1, cia2, cia3, assignment, total)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            cia1 = VALUES(cia1),
            cia2 = VALUES(cia2),
            cia3 = VALUES(cia3),
            assignment = VALUES(assignment),
            total = VALUES(total)
        ");
        
        $total = $_POST['cia1'] + $_POST['cia2'] + $_POST['cia3'] + $_POST['assignment'];
        
        $stmt->execute([
            $_POST['student_id'],
            $_POST['subject_code'],
            $_POST['subject_name'],
            $_POST['semester'],
            $_POST['cia1'],
            $_POST['cia2'],
            $_POST['cia3'],
            $_POST['assignment'],
            $total
        ]);
        
        $success = "CIA marks updated successfully!";
    } catch(Exception $e) {
        $error = "Error updating CIA marks: " . $e->getMessage();
    }
}

// Fetch all students
$stmt = $conn->prepare("SELECT id, name, reg_no FROM students ORDER BY name");
$stmt->execute();
$students = $stmt->fetchAll();

// Fetch subjects
$stmt = $conn->prepare("SELECT code, name FROM subjects ORDER BY name");
$stmt->execute();
$subjects = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CIA Marks Management</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        <h2>CIA Marks Management</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="cia-form-section">
            <h3>Enter CIA Marks</h3>
            <form method="POST" class="cia-form">
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo $student['name'] . ' (' . $student['reg_no'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="subject_code">Subject</label>
                    <select name="subject_code" id="subject_code" required>
                        <option value="">Select Subject</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['code']; ?>" 
                                    data-name="<?php echo $subject['name']; ?>">
                                <?php echo $subject['code'] . ' - ' . $subject['name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="hidden" name="subject_name" id="subject_name">
                </div>

                <div class="form-group">
                    <label for="semester">Semester</label>
                    <select name="semester" required>
                        <?php for($i = 1; $i <= 8; $i++): ?>
                            <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="marks-grid">
                    <div class="form-group">
                        <label for="cia1">CIA 1 (Max: 50)</label>
                        <input type="number" name="cia1" min="0" max="50" required>
                    </div>

                    <div class="form-group">
                        <label for="cia2">CIA 2 (Max: 50)</label>
                        <input type="number" name="cia2" min="0" max="50" required>
                    </div>

                    <div class="form-group">
                        <label for="cia3">CIA 3 (Max: 50)</label>
                        <input type="number" name="cia3" min="0" max="50" required>
                    </div>

                    <div class="form-group">
                        <label for="assignment">Assignment (Max: 50)</label>
                        <input type="number" name="assignment" min="0" max="50" required>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Save Marks</button>
            </form>
        </div>

        <div id="marksDisplay" class="marks-display">
            <!-- AJAX will populate this section -->
        </div>
    </div>

    <script>
        // Update hidden subject name field when subject is selected
        document.getElementById('subject_code').addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            document.getElementById('subject_name').value = selected.dataset.name;
        });

        // Load existing marks when student is selected
        document.getElementById('student_id').addEventListener('change', function() {
            const studentId = this.value;
            if (!studentId) return;

            fetch(`get_cia_marks.php?student_id=${studentId}`)
                .then(response => response.json())
                .then(data => {
                    const marksDisplay = document.getElementById('marksDisplay');
                    if (data.length === 0) {
                        marksDisplay.innerHTML = '<p>No CIA marks found for this student.</p>';
                        return;
                    }

                    let html = '<h3>Existing CIA Marks</h3><table class="marks-table">';
                    html += '<thead><tr><th>Subject</th><th>Semester</th><th>CIA 1</th><th>CIA 2</th><th>CIA 3</th><th>Assignment</th><th>Total</th></tr></thead><tbody>';
                    
                    data.forEach(mark => {
                        html += `<tr>
                            <td>${mark.subject_name}</td>
                            <td>${mark.semester}</td>
                            <td>${mark.cia1}</td>
                            <td>${mark.cia2}</td>
                            <td>${mark.cia3}</td>
                            <td>${mark.assignment}</td>
                            <td>${mark.total}</td>
                        </tr>`;
                    });

                    html += '</tbody></table>';
                    marksDisplay.innerHTML = html;
                });
        });
    </script>
</body>
</html>