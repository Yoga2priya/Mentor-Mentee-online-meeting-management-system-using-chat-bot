<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

$database = new Database();
$conn = $database->getConnection();

$student_id = $_GET['student_id'] ?? null;

if (!$student_id) {
    header('HTTP/1.1 400 Bad Request');
    exit('Student ID is required');
}

$stmt = $conn->prepare("
    SELECT * FROM semester_marks 
    WHERE student_id = ?
    ORDER BY semester, sub_code
");
$stmt->execute([$student_id]);
$marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($marks);