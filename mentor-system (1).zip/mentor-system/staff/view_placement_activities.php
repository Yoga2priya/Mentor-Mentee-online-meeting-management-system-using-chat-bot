<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStaffLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_GET['student_id'] ?? null;

if (!$student_id) {
    header('Location: dashboard.php');
    exit();
}

// Fetch student's placement activities
$stmt = $conn->prepare("
    SELECT 
        s.name as student_name,
        s.reg_no,
        s.long_absence,
        s.disciplinary_actions,
        s.marital_status,
        ci.*,
        rd.*
    FROM students s
    LEFT JOIN campus_interviews ci ON s.id = ci.student_id
    LEFT JOIN recruitment_details rd ON s.id = rd.student_id
    WHERE s.id = ?
");
$stmt->execute([$student_id]);
$activities = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Placement Activities</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    <div class="container">
        <h2>Placement Activities - <?php echo $activities[0]['student_name']; ?></h2>
        
        <div class="section">
            <h3>Campus Interview Data</h3>
            <?php if (empty($activities) || empty($activities[0]['company_name'])): ?>
                <p class="no-data-message">No campus interview data available.</p>
            <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Name of the Company - Attended</th>
                            <th>Venue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($activities as $activity): 
                            if (!empty($activity['company_name'])): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($activity['interview_date'])); ?></td>
                                <td><?php echo htmlspecialchars($activity['company_name']); ?></td>
                                <td><?php echo htmlspecialchars($activity['venue']); ?></td>
                            </tr>
                        <?php 
                            endif;
                        endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="section">
            <h3>Recruitment Details</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Name of the Recruited Company & Details</th>
                        <th>Annual Salary Package</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($activities[0]['company_name'])): ?>
                        <tr>
                            <td><?php echo date('d-m-Y', strtotime($activities[0]['offer_date'])); ?></td>
                            <td><?php echo htmlspecialchars($activities[0]['company_name']); ?></td>
                            <td><?php echo number_format($activities[0]['package'], 2); ?> LPA</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="section">
            <h3>Additional Information</h3>
            <div class="info-grid">
                <div class="info-item absent">
                    <label>Long Absent / Discontinue</label>
                    <p><?php echo htmlspecialchars($activities[0]['long_absence'] ?? 'N/A'); ?></p>
                </div>
                
                <div class="info-item disciplinary">
                    <label>Disciplinary Activities</label>
                    <p><?php echo htmlspecialchars($activities[0]['disciplinary_actions'] ?? 'N/A'); ?></p>
                </div>
                
                <div class="info-item marital">
                    <label>Whether Married</label>
                    <p><?php echo ucfirst($activities[0]['marital_status'] ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>