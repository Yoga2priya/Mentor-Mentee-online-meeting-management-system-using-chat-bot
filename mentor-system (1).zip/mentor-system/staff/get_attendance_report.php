<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

$database = new Database();
$conn = $database->getConnection();

$subject_code = $_GET['subject_code'] ?? null;

if (!$subject_code) {
    header('HTTP/1.1 400 Bad Request');
    exit('Subject code is required');
}

$stmt = $conn->prepare("
    SELECT 
        s.reg_no,
        s.name,
        COUNT(*) as total_classes,
        SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
        SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_count,
        SUM(CASE WHEN a.status = 'leave' THEN 1 ELSE 0 END) as leave_count
    FROM students s
    LEFT JOIN attendance a ON s.id = a.student_id AND a.subject_code = ?
    GROUP BY s.id, s.reg_no, s.name
    ORDER BY s.name
");
$stmt->execute([$subject_code]);
$report = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($report);