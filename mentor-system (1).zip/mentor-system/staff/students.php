<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Get all students
$stmt = $conn->prepare("
    SELECT s.*, a.*
    FROM students s
    LEFT JOIN academic_records a ON s.id = a.student_id
    ORDER BY s.name
");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Bio Data</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <h2>Students Bio Data</h2>

        <div class="search-section">
            <input type="text" id="studentSearch" placeholder="Search by name or register number..." class="search-input">
        </div>

        <div class="students-grid">
            <?php foreach ($students as $student): ?>
                <div class="student-card" data-name="<?php echo strtolower($student['name']); ?>" 
                     data-regno="<?php echo strtolower($student['reg_no']); ?>">
                    <div class="student-header">
                        <div class="student-photo">
                            <?php if (!empty($student['photo_path'])): ?>
                                <img src="<?php echo '../' . $student['photo_path']; ?>" alt="Student Photo">
                            <?php else: ?>
                                <div class="no-photo">No Photo</div>
                            <?php endif; ?>
                        </div>
                        <div class="student-basic-info">
                            <h3><?php echo htmlspecialchars($student['name']); ?></h3>
                            <p>Reg No: <?php echo htmlspecialchars($student['reg_no']); ?></p>
                            <p>Department: <?php echo htmlspecialchars($student['department']); ?></p>
                            <p>Year: <?php echo htmlspecialchars($student['year']); ?></p>
                        </div>
                    </div>
                    
                    <div class="student-details">
                        <h4>Contact Information</h4>
                        <p><strong>Mobile:</strong> <?php echo htmlspecialchars($student['mobile_no']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
                        
                        <h4>Academic Records</h4>
                        <div class="academic-info">
                            <p><strong>10th:</strong> <?php echo $student['tenth_percentage']; ?>%</p>
                            <p><strong>12th:</strong> <?php echo $student['twelfth_percentage']; ?>%</p>
                            <?php if ($student['diploma_percentage']): ?>
                                <p><strong>Diploma:</strong> <?php echo $student['diploma_percentage']; ?>%</p>
                            <?php endif; ?>
                        </div>

                        <button class="view-details-btn" onclick="window.location.href='view_student.php?id=<?php echo $student['id']; ?>'">
                            View Full Details
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        document.getElementById('studentSearch').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const cards = document.querySelectorAll('.student-card');
            
            cards.forEach(card => {
                const name = card.dataset.name;
                const regno = card.dataset.regno;
                
                if (name.includes(searchTerm) || regno.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>