<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        $stmt = $conn->prepare("
            INSERT INTO attendance (student_id, subject_code, date, status, added_by)
            VALUES (?, ?, ?, ?, ?)
        ");

        foreach ($_POST['students'] as $student_id => $status) {
            $stmt->execute([
                $student_id,
                $_POST['subject_code'],
                $_POST['date'],
                $status,
                $_SESSION['staff_id']
            ]);
        }
        
        $conn->commit();
        $success = "Attendance marked successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

// Fetch subjects
$stmt = $conn->prepare("SELECT code, name FROM subjects ORDER BY name");
$stmt->execute();
$subjects = $stmt->fetchAll();

// Fetch students
$stmt = $conn->prepare("SELECT id, name, reg_no FROM students ORDER BY name");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        <h2>Attendance Management</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="attendance-section">
            <h3>Mark Attendance</h3>
            <form method="POST" class="attendance-form">
                <div class="form-header">
                    <div class="form-group">
                        <label for="subject_code">Subject</label>
                        <select name="subject_code" id="subject_code" required>
                            <option value="">Select Subject</option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo $subject['code']; ?>">
                                    <?php echo $subject['code'] . ' - ' . $subject['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>

                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Register No</th>
                            <th>Student Name</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['reg_no']); ?></td>
                                <td><?php echo htmlspecialchars($student['name']); ?></td>
                                <td>
                                    <select name="students[<?php echo $student['id']; ?>]" required>
                                        <option value="present">Present</option>
                                        <option value="absent">Absent</option>
                                        <option value="leave">Leave</option>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <button type="submit" class="btn-submit">Save Attendance</button>
            </form>
        </div>

        <div id="attendanceReport" class="attendance-report">
            <!-- AJAX will populate this section -->
        </div>
    </div>

    <script>
        document.getElementById('subject_code').addEventListener('change', loadAttendanceReport);
        
        function loadAttendanceReport() {
            const subjectCode = document.getElementById('subject_code').value;
            if (!subjectCode) return;

            fetch(`get_attendance_report.php?subject_code=${subjectCode}`)
                .then(response => response.json())
                .then(data => {
                    const reportDiv = document.getElementById('attendanceReport');
                    if (data.length === 0) {
                        reportDiv.innerHTML = '<p>No attendance records found for this subject.</p>';
                        return;
                    }

                    let html = '<h3>Attendance Report</h3>';
                    html += '<table class="report-table">';
                    html += `<thead><tr>
                        <th>Register No</th>
                        <th>Student Name</th>
                        <th>Total Classes</th>
                        <th>Present</th>
                        <th>Absent</th>
                        <th>Leave</th>
                        <th>Percentage</th>
                    </tr></thead><tbody>`;

                    data.forEach(record => {
                        const percentage = ((record.present_count / record.total_classes) * 100).toFixed(2);
                        const statusClass = percentage >= 75 ? 'good-attendance' : 'poor-attendance';

                        html += `<tr class="${statusClass}">
                            <td>${record.reg_no}</td>
                            <td>${record.name}</td>
                            <td>${record.total_classes}</td>
                            <td>${record.present_count}</td>
                            <td>${record.absent_count}</td>
                            <td>${record.leave_count}</td>
                            <td>${percentage}%</td>
                        </tr>`;
                    });

                    html += '</tbody></table>';
                    reportDiv.innerHTML = html;
                });
        }
    </script>
</body>
</html>