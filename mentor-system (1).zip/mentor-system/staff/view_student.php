<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Get student ID from URL parameter
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$student_id) {
    header('Location: students.php');
    exit();
}

// Fetch student data with academic records
$stmt = $conn->prepare("
    SELECT s.*, a.*
    FROM students s
    LEFT JOIN academic_records a ON s.id = a.student_id
    WHERE s.id = ?
");

if (!$stmt->execute([$student_id])) {
    die("Error executing query: " . print_r($stmt->errorInfo(), true));
}

$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die("No student found with ID: " . $student_id);
}

// Fetch semester marks
$stmt = $conn->prepare("
    SELECT * FROM semester_marks 
    WHERE student_id = ? 
    ORDER BY semester, sub_code
");
$stmt->execute([$student_id]);
$marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle remark submission
if (isset($_POST['add_remark'])) {
    try {
        $stmt = $conn->prepare("
            INSERT INTO remarks (student_id, remark, added_by) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([
            $student_id,
            $_POST['remark'],
            $_SESSION['user_name']
        ]);
        $success = "Remark added successfully!";
    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <style>
        .student-details-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        .student-header {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        .student-photo {
            width: 200px;
            height: 200px;
            overflow: hidden;
            border-radius: 10px;
        }
        .student-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .marks-table th, .marks-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .marks-table th {
            background-color: #f5f5f5;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h3 {
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .attendance-table th, .attendance-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .attendance-table th {
            background-color: #f5f5f5;
        }
        .remarks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .remarks-table th, .remarks-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .remarks-table th {
            background-color: #f5f5f5;
        }
        .remark-form {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 10px;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btn-submit {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>

    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <div class="student-details-container">
        <div class="student-header">
            <div class="student-photo">
                <?php if (!empty($student['photo_path'])): ?>
                    <img src="<?php echo '../' . $student['photo_path']; ?>" alt="Student Photo">
                <?php else: ?>
                    <div class="no-photo">No Photo Available</div>
                <?php endif; ?>
            </div>
            <div>
                <h2><?php echo htmlspecialchars($student['name']); ?></h2>
                <p><strong>Register Number:</strong> <?php echo htmlspecialchars($student['reg_no']); ?></p>
                <p><strong>Department:</strong> <?php echo htmlspecialchars($student['department']); ?></p>
                <p><strong>Year:</strong> <?php echo htmlspecialchars($student['year']); ?></p>
            </div>
        </div>

        <div class="section">
            <h3>Personal Information</h3>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Mobile:</strong> <?php echo htmlspecialchars($student['mobile_no']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($student['address']); ?></p>
        </div>

        <div class="section">
            <h3>Academic Records</h3>
            <p><strong>10th Percentage:</strong> <?php echo $student['tenth_percentage']; ?>%</p>
            <p><strong>12th Percentage:</strong> <?php echo $student['twelfth_percentage']; ?>%</p>
            <?php if ($student['diploma_percentage']): ?>
                <p><strong>Diploma Percentage:</strong> <?php echo $student['diploma_percentage']; ?>%</p>
            <?php endif; ?>
        </div>

        <div class="section">
            <h3>Semester Marks</h3>
            <table class="marks-table">
                <thead>
                    <tr>
                        <th>Semester</th>
                        <th>Sub Code</th>
                        <th>Sub Title</th>
                        <th>CIA 1</th>
                        <th>CIA 2</th>
                        <th>Model</th>
                        <th>Internal</th>
                        <th>ESE Mark</th>
                        <th>Total</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($marks as $mark): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($mark['semester']); ?></td>
                            <td><?php echo htmlspecialchars($mark['sub_code']); ?></td>
                            <td><?php echo htmlspecialchars($mark['sub_title']); ?></td>
                            <td><?php echo $mark['cia_1']; ?></td>
                            <td><?php echo $mark['cia_2']; ?></td>
                            <td><?php echo $mark['model']; ?></td>
                            <td><?php echo $mark['internal']; ?></td>
                            <td><?php echo $mark['ese_mark']; ?></td>
                            <td><?php echo $mark['total']; ?></td>
                            <td><?php echo $mark['percentage']; ?>%</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="section">
            <h3>Attendance Records</h3>
            <!-- Odd Semesters -->
            <table class="attendance-table">
                <thead>
                    <tr>
                        <th>SEM</th>
                        <th colspan="2">JUN</th>
                        <th>%</th>
                        <th colspan="2">JUL</th>
                        <th>%</th>
                        <th colspan="2">AUG</th>
                        <th>%</th>
                        <th colspan="2">SEP</th>
                        <th>%</th>
                        <th colspan="2">OCT</th>
                        <th>%</th>
                        <th colspan="2">NOV</th>
                        <th>%</th>
                        <th>Total %</th>
                    </tr>
                    <tr>
                        <th></th>
                        <?php for($i = 0; $i < 6; $i++): ?>
                            <th>Days</th>
                            <th>Total</th>
                            <th></th>
                        <?php endfor; ?>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $odd_semesters = ['I', 'III', 'V'];
                    foreach ($odd_semesters as $sem):
                        $stmt = $conn->prepare("
                            SELECT * FROM attendance_records 
                            WHERE student_id = ? AND semester = ?
                            ORDER BY month
                        ");
                        $stmt->execute([$student_id, $sem]);
                        $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    <tr>
                        <td><?php echo $sem; ?></td>
                        <?php
                        $months = ['JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV'];
                        foreach ($months as $month):
                            $record = array_filter($attendance, function($a) use ($month) {
                                return $a['month'] === $month;
                            });
                            $record = reset($record);
                        ?>
                            <td><?php echo $record ? ($record['attendance_percentage'] * $record['total_days'] / 100) : '-'; ?></td>
                            <td><?php echo $record ? $record['total_days'] : '-'; ?></td>
                            <td><?php 
                                if ($record && $record['total_days'] > 0) {
                                    echo number_format($record['attendance_percentage'], 2) . '%';
                                } else {
                                    echo '-';
                                }
                            ?></td>
                        <?php endforeach; ?>
                        <td class="semester-total">
                            <?php
                            $total_days = array_sum(array_column($attendance, 'total_days'));
                            $weighted_percentage = 0;
                            foreach ($attendance as $record) {
                                $weighted_percentage += $record['attendance_percentage'] * $record['total_days'];
                            }
                            if ($total_days > 0) {
                                $total_percentage = $weighted_percentage / $total_days;
                                echo number_format($total_percentage, 2) . '%';
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Even Semesters -->
            <table class="attendance-table" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th>SEM</th>
                        <th colspan="2">DEC</th>
                        <th>%</th>
                        <th colspan="2">JAN</th>
                        <th>%</th>
                        <th colspan="2">FEB</th>
                        <th>%</th>
                        <th colspan="2">MAR</th>
                        <th>%</th>
                        <th colspan="2">APR</th>
                        <th>%</th>
                        <th colspan="2">MAY</th>
                        <th>%</th>
                        <th>Total %</th>
                    </tr>
                    <tr>
                        <th></th>
                        <?php for($i = 0; $i < 6; $i++): ?>
                            <th>Days</th>
                            <th>Total</th>
                            <th></th>
                        <?php endfor; ?>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $even_semesters = ['II', 'IV', 'VI'];
                    foreach ($even_semesters as $sem):
                        $stmt = $conn->prepare("
                            SELECT * FROM attendance_records 
                            WHERE student_id = ? AND semester = ?
                            ORDER BY month
                        ");
                        $stmt->execute([$student_id, $sem]);
                        $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    <tr>
                        <td><?php echo $sem; ?></td>
                        <?php
                        $months = ['DEC', 'JAN', 'FEB', 'MAR', 'APR', 'MAY'];
                        foreach ($months as $month):
                            $record = array_filter($attendance, function($a) use ($month) {
                                return $a['month'] === $month;
                            });
                            $record = reset($record);
                        ?>
                            <td><?php echo $record ? ($record['attendance_percentage'] * $record['total_days'] / 100) : '-'; ?></td>
                            <td><?php echo $record ? $record['total_days'] : '-'; ?></td>
                            <td><?php 
                                if ($record && $record['total_days'] > 0) {
                                    echo number_format($record['attendance_percentage'], 2) . '%';
                                } else {
                                    echo '-';
                                }
                            ?></td>
                        <?php endforeach; ?>
                        <td class="semester-total">
                            <?php
                            $total_days = array_sum(array_column($attendance, 'total_days'));
                            $weighted_percentage = 0;
                            foreach ($attendance as $record) {
                                $weighted_percentage += $record['attendance_percentage'] * $record['total_days'];
                            }
                            if ($total_days > 0) {
                                $total_percentage = $weighted_percentage / $total_days;
                                echo number_format($total_percentage, 2) . '%';
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Remarks Section -->
        <div class="section">
            <h3>Student Mentorship Reports</h3>
            <?php
            $stmt = $conn->prepare("
                SELECT mr.*, s.name as student_name 
                FROM mentorship_reports mr
                JOIN students s ON mr.student_id = s.id
                WHERE mr.student_id = ?
                ORDER BY mr.date DESC
            ");
            $stmt->execute([$student_id]);
            $mentorship_reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>
            
            <?php if (empty($mentorship_reports)): ?>
                <p>No mentorship reports available.</p>
            <?php else: ?>
                <table class="remarks-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Issues Discussed</th>
                            <th>Action Taken</th>
                            <th>Student Sign</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($mentorship_reports as $report): ?>
                            <tr>
                                <td><?php echo date('d-m-Y', strtotime($report['date'])); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($report['issues_discussed'])); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($report['action_taken'])); ?></td>
                                <td><?php echo $report['student_sign'] ? 'Signed' : 'Not Signed'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="section">
            <h3>Placement Activities</h3>
            <a href="view_placement_activities.php?student_id=<?php echo $student_id; ?>" class="btn-link">
                View Placement Activities
            </a>
        </div>
    </div>
</body>
</html>
