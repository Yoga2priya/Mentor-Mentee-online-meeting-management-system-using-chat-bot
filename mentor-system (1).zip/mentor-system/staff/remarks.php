<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $conn->prepare("
            INSERT INTO remarks (student_id, staff_id, remark)
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([
            $_POST['student_id'],
            $_SESSION['staff_id'],
            $_POST['remark']
        ]);
        
        $success = "Remark added successfully!";
    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}

// Fetch all students
$stmt = $conn->prepare("SELECT id, name, reg_no FROM students ORDER BY name");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Remarks</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <h2>Student Remarks Management</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="remarks-section">
            <h3>Add New Remark</h3>
            <form method="POST" class="remarks-form">
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo $student['name'] . ' (' . $student['reg_no'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="remark">Remark</label>
                    <textarea name="remark" rows="4" required 
                              placeholder="Enter your remarks about the student..."></textarea>
                </div>

                <button type="submit" class="btn-submit">Add Remark</button>
            </form>
        </div>

        <div id="existingRemarks" class="existing-remarks">
            <!-- AJAX will populate this section -->
        </div>
    </div>

    <script>
        document.getElementById('student_id').addEventListener('change', function() {
            const studentId = this.value;
            if (!studentId) return;

            fetch(`get_remarks.php?student_id=${studentId}`)
                .then(response => response.json())
                .then(data => {
                    const remarksDiv = document.getElementById('existingRemarks');
                    if (data.length === 0) {
                        remarksDiv.innerHTML = '<p>No remarks found for this student.</p>';
                        return;
                    }

                    let html = '<h3>Previous Remarks</h3>';
                    html += '<div class="remarks-container">';
                    
                    data.forEach(remark => {
                        html += `
                            <div class="remark-card">
                                <div class="remark-header">
                                    <div class="staff-info">
                                        <h4>${remark.staff_name}</h4>
                                        <p class="designation">${remark.designation}</p>
                                    </div>
                                    <div class="remark-date">
                                        ${new Date(remark.created_at).toLocaleString()}
                                    </div>
                                </div>
                                <div class="remark-content">
                                    ${remark.remark.replace(/\n/g, '<br>')}
                                </div>
                            </div>
                        `;
                    });

                    html += '</div>';
                    remarksDiv.innerHTML = html;
                });
        });
    </script>
</body>
</html>