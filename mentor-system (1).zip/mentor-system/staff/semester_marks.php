<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

if ($_SESSION['user_type'] !== 'staff') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $conn->beginTransaction();
        
        $stmt = $conn->prepare("INSERT INTO semester_marks 
            (student_id, semester, sub_code, sub_title, cia_1, cia_2, model, 
            internal, ese_mark, total, attempts_1, attempts_2, 
            passing_month, passing_year, percentage) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $internal = ($_POST['cia_1'] + $_POST['cia_2'] + $_POST['model']) / 3;
        $total = $internal + $_POST['ese_mark'];
        $percentage = ($total / 100) * 100;
        
        $stmt->execute([
            $_POST['student_id'],
            $_POST['semester'],
            $_POST['sub_code'],
            $_POST['sub_title'],
            $_POST['cia_1'],
            $_POST['cia_2'],
            $_POST['model'],
            $internal,
            $_POST['ese_mark'],
            $total,
            isset($_POST['attempts_1']) ? 1 : 0,
            isset($_POST['attempts_2']) ? 1 : 0,
            $_POST['passing_month'],
            $_POST['passing_year'],
            $percentage
        ]);
        
        $conn->commit();
        $success = "Marks entered successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

// Fetch all students for dropdown
$stmt = $conn->prepare("SELECT id, name, reg_no FROM students ORDER BY name");
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester Marks Management</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        <h2>Semester Marks Management</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="marks-entry-section">
            <h3>Enter Semester Marks</h3>
            <form method="POST" class="marks-form">
                <div class="form-group">
                    <label for="student_id">Student</label>
                    <select name="student_id" id="student_id" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo $student['name'] . ' (' . $student['reg_no'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="semester">Semester</label>
                    <select name="semester" required>
                        <?php for($i = 1; $i <= 8; $i++): ?>
                            <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <table class="marks-table">
                    <thead>
                        <tr>
                            <th>Sub Code</th>
                            <th>Sub Title</th>
                            <th>CIA 1</th>
                            <th>CIA 2</th>
                            <th>Model</th>
                            <th>ESE Mark</th>
                            <th>Attempts</th>
                            <th>Passing Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="text" name="sub_code" required></td>
                            <td><input type="text" name="sub_title" required></td>
                            <td><input type="number" step="0.01" name="cia_1" required></td>
                            <td><input type="number" step="0.01" name="cia_2" required></td>
                            <td><input type="number" step="0.01" name="model" required></td>
                            <td><input type="number" step="0.01" name="ese_mark" required></td>
                            <td>
                                <label><input type="checkbox" name="attempts_1"> I</label>
                                <label><input type="checkbox" name="attempts_2"> II</label>
                            </td>
                            <td>
                                <select name="passing_month" required>
                                    <?php
                                    $months = ['January', 'February', 'March', 'April', 'May', 'June', 
                                             'July', 'August', 'September', 'October', 'November', 'December'];
                                    foreach ($months as $month): ?>
                                        <option value="<?php echo $month; ?>"><?php echo $month; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="passing_year" required>
                                    <?php 
                                    $currentYear = date('Y');
                                    for ($year = $currentYear; $year >= $currentYear - 4; $year--): ?>
                                        <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <button type="submit" class="btn-submit">Save Marks</button>
            </form>
        </div>

        <div id="existingMarks" class="existing-marks">
            <!-- AJAX will populate this section -->
        </div>
    </div>

    <script>
        document.getElementById('student_id').addEventListener('change', function() {
            const studentId = this.value;
            if (!studentId) return;

            fetch(`get_semester_marks.php?student_id=${studentId}`)
                .then(response => response.json())
                .then(data => {
                    const marksDisplay = document.getElementById('existingMarks');
                    if (data.length === 0) {
                        marksDisplay.innerHTML = '<p>No marks found for this student.</p>';
                        return;
                    }

                    let html = '<h3>Existing Marks</h3>';
                    html += '<table class="marks-table">';
                    html += `<thead><tr>
                        <th>Semester</th>
                        <th>Subject</th>
                        <th>CIA 1</th>
                        <th>CIA 2</th>
                        <th>Model</th>
                        <th>Internal</th>
                        <th>ESE</th>
                        <th>Total</th>
                        <th>Percentage</th>
                    </tr></thead><tbody>`;

                    data.forEach(mark => {
                        html += `<tr class="${mark.total >= 50 ? 'pass' : 'fail'}">
                            <td>${mark.semester}</td>
                            <td>${mark.sub_title}</td>
                            <td>${mark.cia_1}</td>
                            <td>${mark.cia_2}</td>
                            <td>${mark.model}</td>
                            <td>${mark.internal}</td>
                            <td>${mark.ese_mark}</td>
                            <td>${mark.total}</td>
                            <td>${mark.percentage}%</td>
                        </tr>`;
                    });

                    html += '</tbody></table>';
                    marksDisplay.innerHTML = html;
                });
        });
    </script>
</body>
</html>