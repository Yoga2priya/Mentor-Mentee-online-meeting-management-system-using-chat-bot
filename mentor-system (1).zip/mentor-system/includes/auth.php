<?php
session_start();

function requireLogin() {
    if (!isset($_SESSION['user_type'])) {
        header('Location: /login.php');
        exit();
    }
}

function requireStaffLogin() {
    requireLogin();
    if ($_SESSION['user_type'] !== 'staff') {
        header('Location: /login.php');
        exit();
    }
}

function requireStudentLogin() {
    requireLogin();
    if ($_SESSION['user_type'] !== 'student') {
        header('Location: /login.php');
        exit();
    }
}
