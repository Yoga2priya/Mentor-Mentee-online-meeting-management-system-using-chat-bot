<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        // Insert campus interview data
        if (!empty($_POST['company_name'])) {
            $stmt = $conn->prepare("
                INSERT INTO campus_interviews 
                (student_id, interview_date, company_name, venue)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $student_id,
                $_POST['interview_date'],
                $_POST['company_name'],
                $_POST['venue']
            ]);
        }

        // Update student additional info
        $stmt = $conn->prepare("
            UPDATE students 
            SET long_absence = ?, disciplinary_actions = ?, marital_status = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $_POST['long_absence'],
            $_POST['disciplinary'],
            $_POST['marital_status'],
            $student_id
        ]);

        $conn->commit();
        $success = "Placement activities updated successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

// Fetch existing interviews
$stmt = $conn->prepare("
    SELECT * FROM campus_interviews 
    WHERE student_id = ? 
    ORDER BY interview_date DESC
");
$stmt->execute([$student_id]);
$interviews = $stmt->fetchAll();

// Fetch student info
$stmt = $conn->prepare("
    SELECT long_absence, disciplinary_actions, marital_status 
    FROM students 
    WHERE id = ?
");
$stmt->execute([$student_id]);
$student_info = $stmt->fetch();

$page_title = "Placement Activities";
require_once '../includes/header.php';
?>

<body>
    <?php require_once 'includes/navbar.php'; ?>
    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2>PLACEMENT ACTIVITIES</h2>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" class="placement-form">
            <div class="section">
                <h3>CAMPUS INTERVIEW DATA</h3>
                <div class="form-group">
                    <label for="interview_date">Date</label>
                    <input type="date" name="interview_date" required>
                </div>
                <div class="form-group">
                    <label for="company_name">Name of the Company - Attended</label>
                    <input type="text" name="company_name" required>
                </div>
                <div class="form-group">
                    <label for="venue">Venue</label>
                    <input type="text" name="venue" required>
                </div>
            </div>

            <div class="section">
                <h3>Additional Information</h3>
                <div class="form-group">
                    <label>Long Absent / Discontinue (Date with Reason)</label>
                    <textarea name="long_absence"><?php echo htmlspecialchars($student_info['long_absence'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Disciplinary Activities</label>
                    <textarea name="disciplinary"><?php echo htmlspecialchars($student_info['disciplinary_actions'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Whether Married</label>
                    <select name="marital_status">
                        <option value="no" <?php echo ($student_info['marital_status'] ?? '') === 'no' ? 'selected' : ''; ?>>No</option>
                        <option value="yes" <?php echo ($student_info['marital_status'] ?? '') === 'yes' ? 'selected' : ''; ?>>Yes</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn-submit">Save Details</button>
        </form>

        <div class="section">
            <h3>Interview History</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Company Name</th>
                        <th>Venue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($interviews as $interview): ?>
                        <tr>
                            <td><?php echo date('d-m-Y', strtotime($interview['interview_date'])); ?></td>
                            <td><?php echo htmlspecialchars($interview['company_name']); ?></td>
                            <td><?php echo htmlspecialchars($interview['venue']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>