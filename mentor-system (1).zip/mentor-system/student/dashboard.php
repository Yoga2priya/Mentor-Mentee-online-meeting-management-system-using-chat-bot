<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

// Fetch logged-in student's details
$stmt = $conn->prepare("
    SELECT * FROM students 
    WHERE id = ? 
    LIMIT 1
");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    header('Location: ../logout.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    <div class="container">
        <h2>Welcome, <?php echo htmlspecialchars($student['name']); ?></h2>
        <div class="dashboard-stats">
            <div class="stat-card">
                <h3>Registration Number</h3>
                <p><?php echo htmlspecialchars($student['reg_no']); ?></p>
            </div>
            <div class="stat-card">
                <h3>Department</h3>
                <p><?php echo htmlspecialchars($student['department']); ?></p>
            </div>
            <div class="stat-card">
                <h3>Year</h3>
                <p><?php echo htmlspecialchars($student['year']); ?></p>
            </div>
        </div>
    </div>
</body>
</html>