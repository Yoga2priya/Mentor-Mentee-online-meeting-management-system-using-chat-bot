<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudentLogin();

$database = new Database();
$conn = $database->getConnection();

// Handle form submission for new marks
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        $stmt = $conn->prepare("
            INSERT INTO semester_marks 
            (student_id, semester, sub_code, sub_title, cia_1, cia_2, model, internal, 
             ese_mark, total, attempts_1, attempts_2, passing_month, passing_year, percentage) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $total = $_POST['cia_1'] + $_POST['cia_2'] + $_POST['model'] + $_POST['internal'] + $_POST['ese_mark'];
        $percentage = ($total / 100) * 100;
        
        $stmt->execute([
            $_SESSION['user_id'],
            $_POST['semester'],
            $_POST['sub_code'],
            $_POST['sub_title'],
            $_POST['cia_1'],
            $_POST['cia_2'],
            $_POST['model'],
            $_POST['internal'],
            $_POST['ese_mark'],
            $total,
            isset($_POST['attempts_1']) ? 1 : 0,
            isset($_POST['attempts_2']) ? 1 : 0,
            $_POST['passing_month'],
            $_POST['passing_year'],
            $percentage
        ]);
        
        $conn->commit();
        $success = "Marks added successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

// Fetch existing marks
$student_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT * FROM semester_marks 
    WHERE student_id = ? 
    ORDER BY semester, sub_code
");
$stmt->execute([$student_id]);
$marks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Semester Marks</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .marks-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }

        .semester-section {
            margin-bottom: 30px;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
        }

        .semester-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }

        .semester-header h3 {
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }

        .semester-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card h4 {
            color: #666;
            font-size: 0.9rem;
            margin: 0 0 5px 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .stat-card p {
            color: #2c3e50;
            font-size: 1.2rem;
            margin: 0;
            font-weight: 600;
        }

        .marks-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .marks-table th {
            background: #f1f5f9;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #475569;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }

        .marks-table td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            color: #1e293b;
        }

        .marks-table tr:last-child td {
            border-bottom: none;
        }

        .marks-table tr:hover {
            background: #f8fafc;
        }

        .score {
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 4px;
            display: inline-block;
            min-width: 60px;
            text-align: center;
        }

        .score-high {
            color: #059669;
            background: #ecfdf5;
        }

        .score-medium {
            color: #b45309;
            background: #fffbeb;
        }

        .score-low {
            color: #dc2626;
            background: #fef2f2;
        }

        .attempts {
            display: inline-flex;
            gap: 5px;
            padding: 4px 8px;
            background: #e2e8f0;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .semester-average {
            background: #f0f9ff;
            padding: 8px 16px;
            border-radius: 6px;
            color: #0369a1;
            font-weight: 500;
        }

        .alert {
            padding: 12px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border: 1px solid #dcfce7;
        }

        .alert-danger {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fee2e2;
        }

        @media (max-width: 768px) {
            .marks-table {
                display: block;
                overflow-x: auto;
            }
            
            .semester-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    
    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <div class="marks-container">
            <h2><i class="fas fa-graduation-cap"></i> Semester Marks</h2>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="form-section">
                <h3><i class="fas fa-plus-circle"></i> Add New Marks</h3>
                <form method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="semester">Semester</label>
                            <select name="semester" id="semester" required>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="sub_code">Subject Code</label>
                            <input type="text" name="sub_code" id="sub_code" required>
                        </div>
                        <div class="form-group">
                            <label for="sub_title">Subject Title</label>
                            <input type="text" name="sub_title" id="sub_title" required>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="cia_1">CIA 1</label>
                            <input type="number" step="0.01" name="cia_1" id="cia_1" required>
                        </div>
                        <div class="form-group">
                            <label for="cia_2">CIA 2</label>
                            <input type="number" step="0.01" name="cia_2" id="cia_2" required>
                        </div>
                        <div class="form-group">
                            <label for="model">Model</label>
                            <input type="number" step="0.01" name="model" id="model" required>
                        </div>
                        <div class="form-group">
                            <label for="internal">Internal</label>
                            <input type="number" step="0.01" name="internal" id="internal" required>
                        </div>
                        <div class="form-group">
                            <label for="ese_mark">ESE Mark</label>
                            <input type="number" step="0.01" name="ese_mark" id="ese_mark" required>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label>Attempts</label>
                            <div class="checkbox-group">
                                <label><input type="checkbox" name="attempts_1"> First Attempt</label>
                                <label><input type="checkbox" name="attempts_2"> Second Attempt</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="passing_month">Passing Month</label>
                            <select name="passing_month" id="passing_month" required>
                                <?php
                                $months = ['January', 'February', 'March', 'April', 'May', 'June', 
                                         'July', 'August', 'September', 'October', 'November', 'December'];
                                foreach($months as $month): ?>
                                    <option value="<?php echo $month; ?>"><?php echo $month; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="passing_year">Passing Year</label>
                            <select name="passing_year" id="passing_year" required>
                                <?php 
                                $currentYear = date('Y');
                                for($year = $currentYear; $year >= $currentYear - 4; $year--): ?>
                                    <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="submit-btn">Add Marks</button>
                </form>
            </div>

            <?php
            $current_semester = null;
            foreach ($marks as $mark):
                if ($current_semester !== $mark['semester']):
                    if ($current_semester !== null): ?>
                        </tbody>
                        </table>
                    </div>
                    <?php endif;
                    $current_semester = $mark['semester'];
            ?>
            
            <div class="semester-section">
                <div class="semester-header">
                    <h3><i class="fas fa-book"></i> Semester <?php echo $mark['semester']; ?></h3>
                    <div class="semester-average">
                        Average: <strong><?php echo calculateSemesterAverage($marks, $mark['semester']); ?>%</strong>
                    </div>
                </div>

                <div class="semester-stats">
                    <div class="stat-card">
                        <h4><i class="fas fa-check-circle"></i> Passed Subjects</h4>
                        <p><?php echo countPassedSubjects($marks, $mark['semester']); ?></p>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-times-circle"></i> Failed Subjects</h4>
                        <p><?php echo countFailedSubjects($marks, $mark['semester']); ?></p>
                    </div>
                    <div class="stat-card">
                        <h4><i class="fas fa-star"></i> Highest Mark</h4>
                        <p><?php echo getHighestMark($marks, $mark['semester']); ?>%</p>
                    </div>
                </div>

                <table class="marks-table">
                    <thead>
                        <tr>
                            <th>Subject Code</th>
                            <th>Subject Title</th>
                            <th>CIA 1</th>
                            <th>CIA 2</th>
                            <th>Model</th>
                            <th>Internal</th>
                            <th>ESE Mark</th>
                            <th>Total</th>
                            <th>Attempts</th>
                            <th>Passing Date</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                <?php endif; ?>
                        <tr>
                            <td><?php echo htmlspecialchars($mark['sub_code']); ?></td>
                            <td><?php echo htmlspecialchars($mark['sub_title']); ?></td>
                            <td><?php echo formatScore($mark['cia_1']); ?></td>
                            <td><?php echo formatScore($mark['cia_2']); ?></td>
                            <td><?php echo formatScore($mark['model']); ?></td>
                            <td><?php echo formatScore($mark['internal']); ?></td>
                            <td><?php echo formatScore($mark['ese_mark']); ?></td>
                            <td><?php echo formatScore($mark['total']); ?></td>
                            <td>
                                <div class="attempts">
                                    <?php 
                                    $attempts = [];
                                    if ($mark['attempts_1']) $attempts[] = 'I';
                                    if ($mark['attempts_2']) $attempts[] = 'II';
                                    echo implode(', ', $attempts);
                                    ?>
                                </div>
                            </td>
                            <td><?php echo $mark['passing_month'] . ' ' . $mark['passing_year']; ?></td>
                            <td>
                                <span class="score <?php echo getScoreClass($mark['percentage']); ?>">
                                    <?php echo $mark['percentage']; ?>%
                                </span>
                            </td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
    // Helper functions
    function calculateSemesterAverage($marks, $semester) {
        $semesterMarks = array_filter($marks, function($mark) use ($semester) {
            return $mark['semester'] == $semester;
        });
        
        if (empty($semesterMarks)) return 0;
        
        $total = array_sum(array_column($semesterMarks, 'percentage'));
        return $total / count($semesterMarks);
    }

    function countPassedSubjects($marks, $semester) {
        $semesterMarks = array_filter($marks, function($mark) use ($semester) {
            return $mark['semester'] == $semester;
        });
        
        $passedSubjects = array_filter($semesterMarks, function($mark) {
            return $mark['percentage'] >= 50;
        });
        
        return count($passedSubjects);
    }

    function countFailedSubjects($marks, $semester) {
        $semesterMarks = array_filter($marks, function($mark) use ($semester) {
            return $mark['semester'] == $semester;
        });
        
        $failedSubjects = array_filter($semesterMarks, function($mark) {
            return $mark['percentage'] < 50;
        });
        
        return count($failedSubjects);
    }

    function getHighestMark($marks, $semester) {
        $semesterMarks = array_filter($marks, function($mark) use ($semester) {
            return $mark['semester'] == $semester;
        });
        
        $highestMark = max(array_column($semesterMarks, 'percentage'));
        return $highestMark;
    }

    function formatScore($score) {
        if ($score >= 80) return '<span class="score score-high">' . $score . '%</span>';
        if ($score >= 60) return '<span class="score score-medium">' . $score . '%</span>';
        return '<span class="score score-low">' . $score . '%</span>';
    }

    function getScoreClass($percentage) {
        if ($percentage >= 80) return 'score-high';
        if ($percentage >= 60) return 'score-medium';
        return 'score-low';
    }
?>
</body>
</html>