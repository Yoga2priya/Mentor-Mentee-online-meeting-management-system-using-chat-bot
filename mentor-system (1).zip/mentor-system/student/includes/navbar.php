<nav class="navbar">
    <div class="nav-brand">
        <a href="dashboard.php" class="brand-link">
            <i class="fas fa-graduation-cap"></i>
            <span>Student Portal</span>
        </a>
    </div>
    
    <div class="nav-links">
        <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="biodata.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'biodata.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Bio Data</span>
        </a>
        <a href="semester_marks.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'semester_marks.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Semester Marks</span>
        </a>
        <a href="attendance.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'active' : ''; ?>">
            <i class="fas fa-calendar-check"></i>
            <span>Attendance</span>
        </a>
        <a href="remarks.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'remarks.php' ? 'active' : ''; ?>">
            <i class="fas fa-comments"></i>
            <span>Remarks</span>
        </a>
        <a href="placement_activities.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'placement_activities.php' ? 'active' : ''; ?>">
            <i class="fas fa-briefcase"></i>
            <span>Placement</span>
        </a>
        <a href="../logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</nav>

<style>
    .navbar {
        background: #ffffff;
        box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        padding: 0.75rem 1.5rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    .nav-brand {
        display: flex;
        align-items: center;
    }

    .brand-link {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-size: 1.25rem;
        font-weight: 600;
        color: #2c3e50;
        text-decoration: none;
        transition: color 0.3s;
    }

    .brand-link:hover {
        color: #3498db;
    }

    .nav-links {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-left: auto;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        color: #64748b;
        text-decoration: none;
        border-radius: 6px;
        transition: all 0.3s;
    }

    .nav-link:hover {
        background: #f1f5f9;
        color: #3498db;
    }

    .nav-link.active {
        background: #e9f2fe;
        color: #3498db;
        font-weight: 500;
    }

    .nav-link i {
        font-size: 1.1rem;
    }

    @media (max-width: 768px) {
        .navbar {
            padding: 0.5rem;
            flex-wrap: wrap;
        }

        .nav-links {
            order: 3;
            width: 100%;
            overflow-x: auto;
            padding: 0.5rem 0;
            gap: 0.25rem;
            justify-content: space-between;
        }

        .nav-link span {
            display: none;
        }

        .nav-link {
            padding: 0.5rem;
        }
    }
</style>