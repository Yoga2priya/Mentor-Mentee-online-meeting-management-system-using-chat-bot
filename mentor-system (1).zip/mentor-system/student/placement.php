<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_SESSION['user_id'];

// Fetch placement records
$stmt = $conn->prepare("
    SELECT p.*, s.name as staff_name
    FROM placement_records p
    LEFT JOIN staff s ON p.added_by = s.id
    WHERE student_id = ?
    ORDER BY offer_date DESC
");
$stmt->execute([$student_id]);
$placements = $stmt->fetchAll();

$page_title = "Placement Records";
require_once '../includes/header.php';
?>

<body>
    <?php require_once 'includes/navbar.php'; ?>

    <div class="container">
        <h2>Placement Records</h2>
        
        <div class="placement-records">
            <?php if (empty($placements)): ?>
                <p class="no-records">No placement records available yet.</p>
            <?php else: ?>
                <?php foreach ($placements as $placement): ?>
                    <div class="placement-card">
                        <h3><?php echo htmlspecialchars($placement['company_name']); ?></h3>
                        <div class="placement-details">
                            <p><strong>Position:</strong> <?php echo htmlspecialchars($placement['position']); ?></p>
                            <p><strong>Package:</strong> ₹<?php echo number_format($placement['package'], 2); ?> LPA</p>
                            <p><strong>Offer Date:</strong> <?php echo date('d M Y', strtotime($placement['offer_date'])); ?></p>
                            <p><strong>Status:</strong> 
                                <span class="status-<?php echo $placement['status']; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $placement['status'])); ?>
                                </span>
                            </p>
                            <p><strong>Added By:</strong> <?php echo htmlspecialchars($placement['staff_name']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>