<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_SESSION['user_id'];

// Fetch student data
$stmt = $conn->prepare("
    SELECT s.*, a.*
    FROM students s
    LEFT JOIN academic_records a ON s.id = a.student_id
    WHERE s.id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Bio Data</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .biodata-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }

        .student-header {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }

        .student-photo {
            width: 200px;
            height: 200px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .student-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .student-basic-info {
            flex: 1;
        }

        .section {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .section h3 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .info-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .info-item label {
            font-weight: 600;
            color: #666;
            font-size: 0.9rem;
        }

        .info-item span {
            padding: 8px;
            background: #f8f9fa;
            border-radius: 5px;
            color: #2c3e50;
        }

        .no-photo {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            background: #f8f9fa;
            color: #666;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    
    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <div class="biodata-container">
        <div class="student-header">
            <div class="student-photo">
                <?php if (!empty($student['photo_path'])): ?>
                    <img src="<?php echo '../' . $student['photo_path']; ?>" alt="Student Photo">
                <?php else: ?>
                    <div class="no-photo">
                        <i class="fas fa-user fa-3x"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div class="student-basic-info">
                <h2><?php echo htmlspecialchars($student['name']); ?></h2>
                <p><i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student['reg_no']); ?></p>
                <p><i class="fas fa-building"></i> <?php echo htmlspecialchars($student['department']); ?></p>
                <p><i class="fas fa-calendar-alt"></i> Year: <?php echo htmlspecialchars($student['year']); ?></p>
            </div>
        </div>

        <div class="section">
            <h3><i class="fas fa-user"></i> Personal Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Name:</label>
                    <span><?php echo $student['name']; ?></span>
                </div>
                <div class="info-item">
                    <label>Registration Number:</label>
                    <span><?php echo $student['reg_no']; ?></span>
                </div>
                <div class="info-item">
                    <label>Address:</label>
                    <span><?php echo $student['address']; ?></span>
                </div>
                <div class="info-item">
                    <label>Gender:</label>
                    <span><?php echo $student['gender']; ?></span>
                </div>
                <div class="info-item">
                    <label>Year:</label>
                    <span><?php echo $student['year']; ?></span>
                </div>
                <div class="info-item">
                    <label>Mobile Number:</label>
                    <span><?php echo $student['mobile_no']; ?></span>
                </div>
                <div class="info-item">
                    <label>Department:</label>
                    <span><?php echo $student['department']; ?></span>
                </div>
                <div class="info-item">
                    <label>Date of Birth:</label>
                    <span><?php echo date('d-m-Y', strtotime($student['dob'])); ?></span>
                </div>
                <div class="info-item">
                    <label>Blood Group:</label>
                    <span><?php echo $student['blood_group']; ?></span>
                </div>
            </div>
        </div>

        <div class="section">
            <h3><i class="fas fa-users"></i> Family Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Father's Name:</label>
                    <span><?php echo $student['fathers_name']; ?></span>
                </div>
                <div class="info-item">
                    <label>Father's Number:</label>
                    <span><?php echo $student['fathers_number']; ?></span>
                </div>
                <div class="info-item">
                    <label>Mother's Name:</label>
                    <span><?php echo $student['mothers_name']; ?></span>
                </div>
                <div class="info-item">
                    <label>Mother's Number:</label>
                    <span><?php echo $student['mothers_number']; ?></span>
                </div>
                <div class="info-item">
                    <label>Guardian's Name:</label>
                    <span><?php echo $student['guardian_name']; ?></span>
                </div>
                <div class="info-item">
                    <label>Guardian's Number:</label>
                    <span><?php echo $student['guardian_number']; ?></span>
                </div>
            </div>
        </div>

        <div class="section">
            <h3><i class="fas fa-graduation-cap"></i> Academic Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>10th School:</label>
                    <span><?php echo $student['tenth_school']; ?></span>
                </div>
                <div class="info-item">
                    <label>10th Marks:</label>
                    <span><?php echo $student['tenth_marks']; ?></span>
                </div>
                <div class="info-item">
                    <label>10th Percentage:</label>
                    <span><?php echo $student['tenth_percentage']; ?>%</span>
                </div>
                
                <div class="info-item">
                    <label>11th School:</label>
                    <span><?php echo $student['eleventh_school']; ?></span>
                </div>
                <div class="info-item">
                    <label>11th Marks:</label>
                    <span><?php echo $student['eleventh_marks']; ?></span>
                </div>
                <div class="info-item">
                    <label>11th Percentage:</label>
                    <span><?php echo $student['eleventh_percentage']; ?>%</span>
                </div>
                
                <div class="info-item">
                    <label>12th School:</label>
                    <span><?php echo $student['twelfth_school']; ?></span>
                </div>
                <div class="info-item">
                    <label>12th Marks:</label>
                    <span><?php echo $student['twelfth_marks']; ?></span>
                </div>
                <div class="info-item">
                    <label>12th Percentage:</label>
                    <span><?php echo $student['twelfth_percentage']; ?>%</span>
                </div>
                
                <div class="info-item">
                    <label>Diploma Percentage:</label>
                    <span><?php echo $student['diploma_percentage']; ?>%</span>
                </div>
                <div class="info-item">
                    <label>UG College:</label>
                    <span><?php echo $student['ug_college']; ?></span>
                </div>
                <div class="info-item">
                    <label>UG Degree:</label>
                    <span><?php echo $student['ug_degree']; ?></span>
                </div>
                <div class="info-item">
                    <label>UG Percentage:</label>
                    <span><?php echo $student['ug_percentage']; ?>%</span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
