<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

// Get student ID from session instead of form selection
$student_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        // Function to handle attendance insertion
        function insertAttendance($conn, $student_id, $semester, $months) {
            foreach ($months as $month) {
                $attendance_key = "attendance_{$semester}_{$month}";
                $total_key = "total_{$semester}_{$month}";
                
                if (isset($_POST[$attendance_key]) && $_POST[$attendance_key] !== '' &&
                    isset($_POST[$total_key]) && $_POST[$total_key] !== '') {
                    
                    $stmt = $conn->prepare("
                        INSERT INTO attendance_records 
                        (student_id, semester, month, attendance_percentage, total_days) 
                        VALUES (?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE 
                        attendance_percentage = VALUES(attendance_percentage),
                        total_days = VALUES(total_days)
                    ");
                    
                    $attendance = intval($_POST[$attendance_key]);
                    $total_days = intval($_POST[$total_key]);
                    $percentage = $total_days > 0 ? min(100, round(($attendance / $total_days) * 100, 2)) : 0;
                    
                    $stmt->execute([
                        $student_id,
                        $semester,
                        $month,
                        $percentage,
                        $total_days
                    ]);
                }
            }
            
            // Only insert semester percentage if it exists and is not empty
            $percentage_key = "percentage_{$semester}";
            if (isset($_POST[$percentage_key]) && $_POST[$percentage_key] !== '') {
                $stmt = $conn->prepare("
                    INSERT INTO semester_attendance 
                    (student_id, semester, percentage) 
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([
                    $student_id,
                    $semester,
                    floatval($_POST[$percentage_key]) // Convert to float
                ]);
            }
        }
        
        // Handle odd semesters
        foreach (['I', 'III', 'V'] as $sem) {
            insertAttendance($conn, $student_id, $sem, 
                ['JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV']);
        }
        
        // Handle even semesters
        foreach (['II', 'IV', 'VI'] as $sem) {
            insertAttendance($conn, $student_id, $sem, 
                ['DEC', 'JAN', 'FEB', 'MAR', 'APR', 'MAY']);
        }
        
        $conn->commit();
        $success = "Attendance records saved successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Entry</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .attendance-container {
            max-width: 1200px;
            margin: 15px auto;
            padding: 15px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e2e8f0;
        }

        .page-header h2 {
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0;
            font-size: 1.5rem;
        }

        .attendance-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 15px 0;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
        }

        .attendance-table th, 
        .attendance-table td {
            padding: 8px 12px;
            text-align: center;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.95rem;
        }

        .attendance-table th {
            background: #f8fafc;
            color: #475569;
            font-weight: 600;
            white-space: nowrap;
        }

        .attendance-table input {
            width: 60px;
            padding: 6px;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            text-align: center;
        }

        .attendance-table input:focus {
            outline: none;
            border-color: #3498db;
        }

        .percentage-cell {
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 4px;
            min-width: 60px;
            display: inline-block;
        }

        .percentage-cell.good { background: #dcfce7; color: #166534; }
        .percentage-cell.warning { background: #fef9c3; color: #854d0e; }
        .percentage-cell.poor { background: #fee2e2; color: #991b1b; }

        .alert {
            padding: 10px 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.95rem;
        }

        .alert-success { background: #f0fdf4; color: #166534; border: 1px solid #dcfce7; }
        .alert-danger { background: #fef2f2; color: #991b1b; border: 1px solid #fee2e2; }

        @media (max-width: 768px) {
            .attendance-table { display: block; overflow-x: auto; }
            .attendance-container { margin: 10px; padding: 10px; }
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    <div class="attendance-container">
        <div class="page-header">
            <h2><i class="fas fa-calendar-check"></i> Attendance Particulars</h2>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="attendance-form">
            <input type="hidden" name="student_id" value="<?php echo $student_id; ?>">

            <!-- First table for Odd Semesters -->
            <table class="attendance-table">
                <thead>
                    <tr>
                        <th>SEM</th>
                        <th colspan="2">JUN</th>
                        <th>%</th>
                        <th colspan="2">JUL</th>
                        <th>%</th>
                        <th colspan="2">AUG</th>
                        <th>%</th>
                        <th colspan="2">SEP</th>
                        <th>%</th>
                        <th colspan="2">OCT</th>
                        <th>%</th>
                        <th colspan="2">NOV</th>
                        <th>%</th>
                        <th>Total %</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (['I', 'III', 'V'] as $sem): ?>
                        <tr>
                            <td><?php echo $sem; ?></td>
                            <?php foreach (['JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV'] as $month): ?>
                                <td>
                                    <input type="number" 
                                           step="1" 
                                           min="0" 
                                           max="31" 
                                           name="attendance_<?php echo $sem . '_' . $month; ?>"
                                           onchange="calculateMonthPercentage('<?php echo $sem; ?>', '<?php echo $month; ?>')"
                                           class="attendance-days">
                                </td>
                                <td>
                                    <input type="number" 
                                           step="1" 
                                           min="0" 
                                           max="31" 
                                           name="total_<?php echo $sem . '_' . $month; ?>"
                                           onchange="calculateMonthPercentage('<?php echo $sem; ?>', '<?php echo $month; ?>')"
                                           class="total-days">
                                </td>
                                <td class="percentage-cell" id="percentage_<?php echo $sem . '_' . $month; ?>">-</td>
                            <?php endforeach; ?>
                            <td class="percentage-cell" id="total_percentage_<?php echo $sem; ?>">-</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Second table for Even Semesters -->
            <table class="attendance-table" style="margin-top: 30px;">
                <thead>
                    <tr>
                        <th>SEM</th>
                        <th colspan="2">DEC</th>
                        <th>%</th>
                        <th colspan="2">JAN</th>
                        <th>%</th>
                        <th colspan="2">FEB</th>
                        <th>%</th>
                        <th colspan="2">MAR</th>
                        <th>%</th>
                        <th colspan="2">APR</th>
                        <th>%</th>
                        <th colspan="2">MAY</th>
                        <th>%</th>
                        <th>Total %</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th>Days</th>
                        <th>Total</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (['II', 'IV', 'VI'] as $sem): ?>
                        <tr>
                            <td><?php echo $sem; ?></td>
                            <?php foreach (['DEC', 'JAN', 'FEB', 'MAR', 'APR', 'MAY'] as $month): ?>
                                <td>
                                    <input type="number" 
                                           step="1" 
                                           min="0" 
                                           max="31" 
                                           name="attendance_<?php echo $sem . '_' . $month; ?>"
                                           onchange="calculateMonthPercentage('<?php echo $sem; ?>', '<?php echo $month; ?>')"
                                           class="attendance-days">
                                </td>
                                <td>
                                    <input type="number" 
                                           step="1" 
                                           min="0" 
                                           max="31" 
                                           name="total_<?php echo $sem . '_' . $month; ?>"
                                           onchange="calculateMonthPercentage('<?php echo $sem; ?>', '<?php echo $month; ?>')"
                                           class="total-days">
                                </td>
                                <td class="percentage-cell" id="percentage_<?php echo $sem . '_' . $month; ?>">-</td>
                            <?php endforeach; ?>
                            <td class="percentage-cell" id="total_percentage_<?php echo $sem; ?>">-</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <button type="submit" class="submit-btn">
                <i class="fas fa-save"></i> Save Attendance
            </button>
        </form>
    </div>

    <script>
        function calculateMonthPercentage(semester, month) {
            const attendanceInput = document.querySelector(`input[name="attendance_${semester}_${month}"]`);
            const totalInput = document.querySelector(`input[name="total_${semester}_${month}"]`);
            
            if (attendanceInput && attendanceInput.value && totalInput && totalInput.value) {
                const attendance = parseInt(attendanceInput.value);
                const total = parseInt(totalInput.value);
                
                if (!isNaN(attendance) && !isNaN(total) && total > 0) {
                    const percentage = (attendance / total) * 100;
                    const percentageCell = document.getElementById(`percentage_${semester}_${month}`);
                    percentageCell.textContent = percentage.toFixed(2) + '%';
                    
                    // Add color coding based on percentage
                    percentageCell.classList.remove('good', 'warning', 'poor');
                    if (percentage >= 75) {
                        percentageCell.classList.add('good');
                    } else if (percentage >= 60) {
                        percentageCell.classList.add('warning');
                    } else {
                        percentageCell.classList.add('poor');
                    }
                }
            }
            
            // Recalculate semester total
            calculateSemesterPercentage(semester);
        }

        function calculateSemesterPercentage(semester) {
            // Define months based on semester (odd or even)
            const isOddSemester = ['I', 'III', 'V'].includes(semester);
            const months = isOddSemester ? 
                ['JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV'] :
                ['DEC', 'JAN', 'FEB', 'MAR', 'APR', 'MAY'];
            
            let totalAttendance = 0;
            let totalDays = 0;
            
            months.forEach(month => {
                const attendanceInput = document.querySelector(`input[name="attendance_${semester}_${month}"]`);
                const totalInput = document.querySelector(`input[name="total_${semester}_${month}"]`);
                
                if (attendanceInput && attendanceInput.value && totalInput && totalInput.value) {
                    const attendance = parseInt(attendanceInput.value);
                    const total = parseInt(totalInput.value);
                    
                    if (!isNaN(attendance) && !isNaN(total) && total > 0) {
                        totalAttendance += attendance;
                        totalDays += total;
                    }
                }
            });
            
            const totalPercentageCell = document.getElementById(`total_percentage_${semester}`);
            
            if (totalDays > 0) {
                const percentage = (totalAttendance / totalDays) * 100;
                totalPercentageCell.textContent = percentage.toFixed(2) + '%';
                
                // Add color coding for semester total
                totalPercentageCell.classList.remove('good', 'warning', 'poor');
                if (percentage >= 75) {
                    totalPercentageCell.classList.add('good');
                } else if (percentage >= 60) {
                    totalPercentageCell.classList.add('warning');
                } else {
                    totalPercentageCell.classList.add('poor');
                }
                
                // Add hidden input for form submission
                let hiddenInput = document.querySelector(`input[name="percentage_${semester}"]`);
                if (!hiddenInput) {
                    hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = `percentage_${semester}`;
                    document.querySelector('form').appendChild(hiddenInput);
                }
                hiddenInput.value = percentage.toFixed(2);
            } else {
                totalPercentageCell.textContent = '-';
                totalPercentageCell.classList.remove('good', 'warning', 'poor');
            }
        }
    </script>
</body>
</html>