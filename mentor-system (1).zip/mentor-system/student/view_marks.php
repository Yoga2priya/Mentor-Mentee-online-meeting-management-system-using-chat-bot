<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM semester_marks WHERE student_id = ? ORDER BY semester, sub_code");
$stmt->execute([$student_id]);
$marks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Marks</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="container">
        <h2>Semester Marks Statement</h2>
        
        <table class="marks-table">
            <thead>
                <tr>
                    <th>Semester</th>
                    <th>Sub Code</th>
                    <th>Sub Title</th>
                    <th>CIA 1</th>
                    <th>CIA 2</th>
                    <th>Model</th>
                    <th>Internal</th>
                    <th>ESE Mark</th>
                    <th>Total</th>
                    <th>Attempts</th>
                    <th>Passing Date</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($marks as $mark): ?>
                    <tr>
                        <td><?php echo $mark['semester']; ?></td>
                        <td><?php echo $mark['sub_code']; ?></td>
                        <td><?php echo $mark['sub_title']; ?></td>
                        <td><?php echo $mark['cia_1']; ?></td>
                        <td><?php echo $mark['cia_2']; ?></td>
                        <td><?php echo $mark['model']; ?></td>
                        <td><?php echo $mark['internal']; ?></td>
                        <td><?php echo $mark['ese_mark']; ?></td>
                        <td><?php echo $mark['total']; ?></td>
                        <td>
                            <?php 
                            $attempts = [];
                            if ($mark['attempts_1']) $attempts[] = 'I';
                            if ($mark['attempts_2']) $attempts[] = 'II';
                            echo implode(', ', $attempts);
                            ?>
                        </td>
                        <td><?php echo $mark['passing_month'] . ' ' . $mark['passing_year']; ?></td>
                        <td><?php echo $mark['percentage']; ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
    