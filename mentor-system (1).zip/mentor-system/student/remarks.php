<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireStudentLogin();

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        $stmt = $conn->prepare("
            INSERT INTO mentorship_reports 
            (student_id, date, issues_discussed, action_taken) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $_SESSION['user_id'],
            $_POST['date'],
            $_POST['issues_discussed'],
            $_POST['action_taken']
        ]);
        
        $conn->commit();
        $success = "Report added successfully!";
    } catch(Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

// Fetch existing reports
$stmt = $conn->prepare("
    SELECT r.*, s.name as student_name
    FROM mentorship_reports r
    JOIN students s ON r.student_id = s.id
    WHERE r.student_id = ?
    ORDER BY r.date DESC
");
$stmt->execute([$_SESSION['user_id']]);
$reports = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Mentorship Report</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #3498db;
        }

        .page-header h2 {
            color: #2c3e50;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .mentorship-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 20px 0;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .mentorship-table th, .mentorship-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e1e8f0;
        }

        .mentorship-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }

        .mentorship-table tr:last-child td {
            border-bottom: none;
        }

        .mentorship-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .signature-column {
            width: 120px;
        }

        .signature {
            display: inline-block;
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border-radius: 4px;
            font-size: 0.9em;
        }

        .form-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-top: 30px;
        }

        .form-section h3 {
            color: #2c3e50;
            margin-top: 0;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e1e8f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-weight: 500;
        }

        .form-group input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #dce4ec;
            border-radius: 4px;
            font-size: 1em;
        }

        .form-group textarea {
            width: 100%;
            min-height: 120px;
            padding: 12px;
            border: 1px solid #dce4ec;
            border-radius: 4px;
            font-size: 1em;
            resize: vertical;
        }

        .btn-submit {
            background-color: #3498db;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }

        .btn-submit:hover {
            background-color: #2980b9;
        }

        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        @media (max-width: 768px) {
            .container {
                padding: 15px;
                margin: 10px;
            }
            
            .mentorship-table {
                display: block;
                overflow-x: auto;
            }
            
            .form-section {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <?php require_once 'includes/navbar.php'; ?>
    <div class="container">
        <a href="dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <div class="page-header">
            <h2><i class="fas fa-comments"></i> Student Mentorship Report</h2>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="reports-section">
            <table class="mentorship-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-calendar"></i> Date</th>
                        <th><i class="fas fa-clipboard-list"></i> Issues Discussed</th>
                        <th><i class="fas fa-tasks"></i> Action Taken</th>
                        <th><i class="fas fa-signature"></i> Sign. Student</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $report): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($report['date'])); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($report['issues_discussed'])); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($report['action_taken'])); ?></td>
                        <td class="signature-column">
                            <?php if ($report['student_sign']): ?>
                                <div class="signature">Signed</div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h3>Add New Report</h3>
        <form method="POST" class="mentorship-form">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" name="date" id="date" required>
            </div>

            <div class="form-group">
                <label for="issues">Issues Discussed:</label>
                <textarea name="issues_discussed" id="issues" required></textarea>
            </div>

            <div class="form-group">
                <label for="action">Action Taken:</label>
                <textarea name="action_taken" id="action" required></textarea>
            </div>

            <button type="submit" class="btn-submit">Save Report</button>
        </form>
    </div>
</body>
</html>