<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireLogin();

$database = new Database();
$conn = $database->getConnection();

$student_id = $_SESSION['user_id'];

// Fetch CIA marks
$stmt = $conn->prepare("
    SELECT subject_code, subject_name, semester, cia1, cia2, cia3, assignment, total
    FROM cia_marks 
    WHERE student_id = ?
    ORDER BY semester, subject_code
");
$stmt->execute([$student_id]);
$cia_marks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CIA Marks</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <!-- Copy navbar from dashboard.php -->
        <?php require_once 'includes/navbar.php'; ?>
    </nav>

    <div class="container">
        <h2>Continuous Internal Assessment Marks</h2>
        
        <table class="marks-table">
            <thead>
                <tr>
                    <th>Semester</th>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                    <th>CIA 1</th>
                    <th>CIA 2</th>
                    <th>CIA 3</th>
                    <th>Assignment</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cia_marks as $mark): ?>
                    <tr>
                        <td><?php echo $mark['semester']; ?></td>
                        <td><?php echo $mark['subject_code']; ?></td>
                        <td><?php echo $mark['subject_name']; ?></td>
                        <td><?php echo $mark['cia1']; ?></td>
                        <td><?php echo $mark['cia2']; ?></td>
                        <td><?php echo $mark['cia3']; ?></td>
                        <td><?php echo $mark['assignment']; ?></td>
                        <td><?php echo $mark['total']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>